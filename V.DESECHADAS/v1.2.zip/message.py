def main_menu(Pant,ang_ROJO,vel_ROJO,ang_AZUL,vel_AZUL):
            click = False
    
    while True:
        #Genera el fondo del juego sin iniciarlo aún
        aux=False
        juego(Pant,aux,ang_ROJO,vel_ROJO,ang_AZUL,vel_AZUL)
        draw_text('Menú', font,Blanco, Pant, (Pant.get_width()/2)-75, 20)
 
        mx, my = pygame.mouse.get_pos()
        boton_1 = pygame.Rect((Pant.get_width()/2)-100, 100, 200, 50)
        boton_2 = pygame.Rect((Pant.get_width()/2)-100, 200, 200, 50)
class pantalla:   
    def _init_(self, mx, my, boton_1, boton_2, click):     
        def boton(self, mx, my, boton_1, boton_2, click):
            if boton_1.collidepoint((mx, my)):
                if click:
                    aux=True           
                    juego(Pant,aux,ang_ROJO,vel_ROJO,ang_AZUL,vel_AZUL)
            if boton_2.collidepoint((mx, my)):
                if click:
                    opciones()
            pygame.draw.rect(Pant, Amarillo, boton_1)
            draw_text('JUEGO', font2, Blanco, Pant, (Pant.get_width()/2)-60, 110)
            pygame.draw.rect(Pant, Amarillo, boton_2)
            draw_text('OPCIONES', font2, Blanco, Pant, (Pant.get_width()/2)-90, 210)
 
            click = False
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()   
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    aux=True
                    juego(Pant,aux,ang_ROJO,vel_ROJO,ang_AZUL,vel_AZUL)
                    
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = True
 
        pygame.display.update()


        #def (self):




class terreno:

    def _init_(self): #constructor tipo init
       
        def superficie(self):
            self.superficie    
        def posicion(self):
    
         def limites(self):
      
            return 


mapa = terreno()          

#class Tanque():
 #   def _init_(self):

  #      def color(self):
        
            # x=tamaño
                     #y=
    

            

#tanqueR= Tanque()      #instanciar tanque objeto
#tanqueA =Tanque()        #instanciar tanque (objeto)
#tanqueR.movimiento(x, y) # deveria moverse