import pygame
import sys
import random as r
from pygame.locals import *
from math import *
import numpy as n
from array import *
pygame.init()

largo=1280
ancho=600

#colores
negro= (0,0,0)
blanco= (255,255,255)
rojo = (255,0,0)
#ventana
ventana=pygame.display.set_mode((largo,ancho))
#variables

#posicion blanco
pox = 250 #posicion de partida de la bala en X naveposx
poy = 500 #posicion de partida de la bala en Y
blancox = 10 #naveancho
blancoy = 10
#posicion rojo
posx2 = 1050 #asteroideposx
posy2 = 500  
rojox = 30 #asteroideancho
rojoy = 30




#ciclo magno
while True:
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if evento.type == pygame.KEYDOWN:
            if evento.type == pygame.K_ESCAPE:
                pygame.quit()
                sys.exit()
    
    #ordenes a la bala
    pox+=1
    
    if posx2 + rojox > pox and posx2 < pox + blancox and posy2 + rojoy > poy and posy2 < poy + blancoy:
        pygame.time.delay(1000)
        pox=0
    #if pox>largo:
    #    pox=0

    #if poy>ancho:
    #    poy=0#Funciona en diagonal
    #if poy<ancho:
    #    poy=600 
    #Implementar que la bola suba hasta alturabala y despues baje


    



    #se rellena la ventana
    ventana.fill(negro)
    pygame.draw.circle(ventana,blanco,(pox,poy),blancox,blancoy)
    pygame.draw.circle(ventana,rojo,(posx2,posy2),rojox,rojoy)
    
    #actualizacion de pantalla
    pygame.display.update()
    pygame.time.delay(5)

pygame.quit()

'''
o = ((45*pi)/180)
vi=90


arreglo=[]
var= 0
for var in range(11):
    xmax=(vi**2)*(sin(2*o))/(9.81)
    x= arreglo.append(xmax)
    var+=1

print(arreglo)


'''